 ^ReadMe_dots 

 ^- File generated on : 2021/07/30 _- 
 ^- Last update : 2021/07/30 _- 
 
 ^- ------------------ -_ 
 ^/ METADATA _/ 
 ^- ------------------ -_ 
 
 ^title Dots pictures _title 
 ^target _target 
 ^author 
   ^name Akpoué Josué _name 
   ^email djosuebetsaleelakpoue@gmail.com _email 
   ^orcid 0000-0002-8384-6516 _orcid 
 _author 
 
 ^- --------------------------------------------- -_ 
 ^/ TECHNICAL INFORMATIONS _/ 
 ^- --------------------------------------------- -_ 
 
 ^// Application used to produce the pictures _// 
 The pictures were deseigned via the application "Simple Draw: Carnet croquis rapide application" v. 5.2.5 installed from Google Play store on Android 8.1.0
 
 ^// Colours used _// 
 ^table 
   ^_line
   ^_nc Colour name ^_nc Hexa ^_nc Usage ^lb
   ^_nc Yellow ^_nc #F9CB03 ^_nc dot colour ^_lb 
   ^_nc Bordeau ^_nc #440303 ^_nc background colour ^_lb 
 _table 
 
 ^- ---------------------------------------------- -_ 
 ^/ OVERVIEW OF THE PICTURES _/ 
 ^- ---------------------------------------------- -_ 
 
 The materials contain 08 pictures in which one can see yellow dots grouped. Each picture name has four parts separated by an underscore. 
  ^* Number of the picture (i.e. from 01 to 08) _*  
  ^* prefix -- i.e. "dots" _* 
  ^* number of groups of dots displayed (i.e. one or four) _* 
  ^* number of dots in each group (separated by "-" when there are four groups) _* 

 Here is the list of the pictures contained in the materials : 
 ^* 01_dots_1_2.png _* 
 ^* 02_dots_1_3.png _* 
 ^* 03_dots_1_4.png _* 
 ^* 04_dots_4_1-2-2-2.png _* 
 ^* 05_dots_4_1-2-3-3.png _* 
 ^* 06_dots_4_2-2-2-2.png _* 
 ^* 07_dots_4_2-2-3-3.png _* 
 ^* 08_dots_4_2-3-3-4.png _* 
  
 ^- ------------------------------------------------ -_ 
 ^/ USER GUIDE (METHODOLOGY) _/ 
 ^- ------------------------------------------------ -_ 
 
 The materials were deseigned to serve as contexts for translated sentences. Originally, it aimed at testing some properties of redupplicated verbs and numerals in Ivorian French.
 So the main task the consultants were submitted to was a truth value judgement task (Tonhauser & Mathewson 2015).
 Here are the Ivorian French sentences provided by the author (who lived in Abidjan, Côte d'Ivoire for more than ten years.)
 ^n*_d01 Ils ont rassemblé rassemblé les graines là. _n* 
 ^n_d02 Ils ont rassemblé rassemblé les points graines là. _n 
 ^n_d03 Ils ont placé placé les graines graines là en tas tas. _n 
 ^n_d04 Ils ont placé placé les points graines là deux deux. _n 
 ^n_d05. Ils ont placé placé les graines graines là deux deux trois trois. _n 
 ^n_d06. Ils ont placé placé les graines graines là deux deux trois trois quatre quatre. _n 
 
 If you want to use the materials with other languages, please use the following sentences (You may adapt them.). Ask your consultant to translate them in the target language first, then elicitate the truth value judgments. 
 If the language allows reddupplication of the verb or the numeral, test whether the translations can contain redupplication of the relevant verb and numeral. If so check the truth value judgments. 
 ^n*_p01 The seeds are gathered. _n 
 ^n_p02 The seeds are placed in a pile. _n 
 ^n_p03 The seeds are piled up two by two. _n 
 ^n_p04 The seeds are piled in groups of two or three. _n 
 ^n_p05 The seeds are piled in groups of two, three or four. _n 
 
 ^- ----------------------------------------- -_ 
 ^/ SHARING INFORMATIONS _/ 
 ^- ----------------------------------------- -_ 
 
 The present materials are distributed under the license of the terms of license Creative Commons CC-BY-NC-SA 4.0
 They are available at github.com/dbjoshua/visualmaterials
 
 ^_* 
 
 _ReadMe 