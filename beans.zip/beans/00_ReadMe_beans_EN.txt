﻿ ^readme_version="1.0"_date="17/05/2025"_update="17/05/2025"_markup="wriml-1.0"  

 ^-  =-=-=-=-  _- 
 ^h1 METADATA  _h1  
 ^-  =-=-=-=-  _-  

  ^title           Beans Pictures           _title 
  ^version         1.0.0                    _version  
  ^date-creation   29/04/2025               _date-creation
  ^time-needed     2h                       _time-needed 
  ^topic           Quantifying determiners  _topic 

  ^target 
    ^= To elicit quantifying determiners in the language under study  _= 
    ^= To identify the basic properties of these determiners (force, distributivity property, basic scope interaction)  _= 
  _target 

 ^creator
  ^name _family  Akpoué                   _name
  ^name _given   Kouamé Josué             _name
  ^email         josueakpoue@gmail.com    _email
  ^orcid         0000-0002-8384-6516      _orcid
 _creator


 ^-  =-=-=-=-=-=-=-=-=-=-=-  _- 
 ^h1 TECHNICAL INFORMATIONS  _h1  
 ^-  =-=-=-=-=-=-=-=-=-=-=-  _-  

 ^h2 Markup language used in this file  _h2 

  This file is written using the WRIML language which is a new markup language (see 26 _WRIML _documentation _EN.md (downloaded from github.com/dbjoshua/WRIML-presentation) for a detailed description of the language).
  Hopefully, the document should be readable as is. But you may find it useful to read the documentation for a better understanding so that you may also use it for your own documents in the future.
  The tag  ^tag = _tag  indicates an item. The empty tag  ^tag _code=" ^_*" * _tag  at the end is just a funny emoji saying "Thank you for reading!".

 ^h2 Source file and images  _h2 

  ^software
   ^name      Inkscape  _name
   ^function  Create the source file (.svg) and export the individual images to PNG  _function
  _software

 ^h2 Credits  _h2

 These materials use original pictures created by the author.


 ^-  =-=-=-=-=-=-=-=-=-=-=-=-=  _h1 
 ^h1 DESCRIPTION OF THE FOLDER  _h1 
 ^-  =-=-=-=-=-=-=-=-=-=-=-=-=  _h1 

 The folder contains 28 files numbered from 00 to 27 and listed below:


 ^= 00_ReadMe_beans_EN.txt        _= 
 ^= 01_ReadMe_beans_FR.txt        _= 
 ^= 02_WRIML_documentation_EN.md  _= 
                                  
 ^= 03_beans_pictures.svg         _=   
 ^= 04_all_in_one.png             _= 
 ^= 05_all_in_only_one.png        _=  
 ^= 06_each_in_one.png            _= 
 ^= 07_not_all_in_one_1.png       _= 
 ^= 08_not_all_in_one_2.png       _= 
 ^= 09_not_all_in_one_3.png       _= 
 ^= 10_not_all_in_one_4.png       _= 
 ^= 11_not_all_in_one_5.png       _=   
 ^= 12_not_all_in_one_6.png       _=   
 ^= 13_not_all_in_one_7.png       _= 
 ^= 14_not_all_in_only_one_1.png  _= 
 ^= 15_not_all_in_only_one_2.png  _= 
 ^= 16_not_all_in_only_one_3.png  _= 
 ^= 17_not_all_in_only_one_4.png  _= 
 ^= 18_not_all_in_only_one_5.png  _= 
 ^= 19_not_all_in_only_one_6.png  _=   
 ^= 20_not_all_in_only_one_7.png  _=   
 ^= 21_not_each_in_one_1.png      _= 
 ^= 22_not_each_in_one_2.png      _=   
 ^= 23_not_each_in_one_3.png      _=   
 ^= 24_not_each_in_one_4.png      _=   
 ^= 25_not_each_in_one_5.png      _= 
 ^= 26_not_each_in_one_6.png      _=  
 ^= 27_not_each_in_one_7.png      _= 




 The file "02_WRIML-documentation_EN.md" is a detailed presentation of WRIML which can also be downloaded
 from github.com/dbjoshua/WRIML-presentation alongside other documentation and introduction files which 
 are roughly the same as this file but in different formats and/or languages.

 The file "03 _beans _pictures.svg" is the source file created using Inkscape while the files 03-* to 27-* are the 
 output pictures.


 ^-  =-=-=-=-=-=-=-=-=-=-=-=-  _h1 
 ^h1 OVERVIEW OF THE PICTURES  _h1 
 ^-  =-=-=-=-=-=-=-=-=-=-=-=-  _h1 

 The materials contain 08 pictures in which one can see beans in pots.
 
 The images "all_in_one" test the wide scope reading of the universal quantifier over the existential quantifier:  
 For each bean, there exists at least one pot in which this bean is.

 The images "each_in_one" test distributivity: Each bean is in its own pot. 

 The images "all_in_only_one" test the wide scope reading of the existential quantifier over the universal 
 quantifier: There exists a pot that contains all the beans.

 The images with the prefix "not_*" test the cases where the previous scenarios are "false".  
 The suffixes "*_1" to "*_7" express the number of beans "outside the pots" (i.e., respectively from 1 to 7 beans).  
 Consequently, the images with the suffix "*_7" are specifically designed to test the negation of the existential 
 quantifier or the wide reading scope of the universal quantifier over negation.


 ^-  -=-=-=-=-=-=-=-=-=-=-=-=  _-
 ^h1 USER GUIDE (METHODOLOGY)  _h1 
 ^-  -=-=-=-=-=-=-=-=-=-=-=-=  _-

 The materials were designed to serve as contexts for translated sentences.
 The main tasks the consultants are to be submitted to are a translation task followed by a truth value judgement task  ^cited Tonhauser & Mathewson 2015  _cited (  ^_bibref_doc-author="Tonhauser, Judith and Mathewson, Lisa"_doc-title="Empirical evidence in research on meaning"_doc-type="ms"_pub-place="online"_doc-publisher="The Ohio State University, University of British Columbia" ).

 Please follow the following steps:

  ^procedure

   ^step_ID="1" Ask the consultant to translate the 12 stimuli sentences (see below)  _step  

   ^rem If multiple translations are possible, differentiate them by suffix letters attached to the corresponding sentence number.  _rem 
    
    ^step_ID="2" For each obtained sentence, present in turn the 23 images of this set and ask the speaker whether this sentence is true in the context depicted in the presented image.  _step 

   _procedure 

  ^stimuli-sentences 
   ^= 01. All the beans are in a plate.                 _= 
   ^= 02. Not all the beans are in a plate.             _= 
   ^= 03. Some beans are in a plate.                    _= 
   ^= 04. Some beans are not in a plate.                _= 
   ^= 05. No bean is in a plate.                        _= 
   ^= 06. Each bean is in a plate.                      _= 
   ^= 07. Several beans are in a plate.                 _= 
   ^= 08. Several beans are not in a plate.             _= 
   ^= 09. Many beans are in a plate.                    _= 
   ^= 10. Many beans are not in a plate.                _= 
   ^= 11. Most beans are in a plate.                    _= 
   ^= 12. Most beans are not in a plate.                _= 
  _stimuli-sentences 

 ^-  -=-=-=-=-=-=-=-=-=-=  _-
 ^h1 SHARING INFORMATIONS  _h1
 ^-  -=-=-=-=-=-=-=-=-=-=  _-

 ^license The present materials are distributed under the license Creative Commons CC-BY-NC-SA 4.0  _license
 ^url They are available at github.com/dbjoshua/visualmaterials  _url

 ^_*

 _readme 
