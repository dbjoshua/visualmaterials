﻿ ^readme_version="1.0"_date="17/05/2025"_update="17/05/2025"_balisage="wriml-1.0"

  ^-  =-=-=-=-=-= _- 
  ^h1 MÉTADONNÉES _h1  
  ^-  =-=-=-=-=-= _-  

  ^titre             Beans Pictures               _titre 
  ^version           1.0.0                        _version  
  ^date-création     29/04/2025                   _date-création
  ^temps-nécessaire  2h                           _temps-nécessaire 
  ^sujet             Déterminants quantificateurs _sujet 

  ^cible 
   ^= Eliciter les déterminants quantificateurs dans la langue d'étude _= 
   ^= Dégager les propriétés de base de ces déterminants (force, propriété de distributivité, interaction de portée basique) _= 
  _cible 

  ^créateur
   ^nom_famille  Akpoué                  _nom_famille
   ^nom_prénom   Kouamé Josué            _nom_prénom
   ^email        josueakpoue@gmail.com   _email
   ^orcid        0000-0002-8384-6516     _orcid
  _créateur


  ^-  =-=-=-=-=-=-=-=-=-=-=- _- 
  ^h1 INFORMATIONS TECHNIQUES _h1  
  ^-  =-=-=-=-=-=-=-=-=-=-=- _-  

  ^h2 Langage de balisage utilisé dans ce fichier _h2 

Ce fichier est écrit en utilisant le langage WRIML, qui est un nouveau langage de balisage (voir 02_WRIML_documentation_EN.md (téléchargeable depuis github.com/dbjoshua/WRIML-presentation) pour une description détaillée).
Le document devrait être lisible tel quel. Mais il peut être utile de consulter la documentation pour mieux comprendre et pouvoir l’utiliser pour vos propres documents à l’avenir.
La balise ^balise = _balise indique un élément de liste. La balise vide   ^balise_code=" ^_*" * _balise en fin de document est une petite image emoji signifiant "Merci de votre lecture !".

  ^h2 Fichier source et images _h2 

  ^logiciel
   ^nom       Inkscape _nom
   ^fonction  Créer le fichier source (.svg) et exporter les images individuelles en PNG _fonction
  _logiciel

  ^h2 Crédits _h2

   Ces documents utilisent des images originales créées par l’auteur.


  ^-  =-=-=-=-=-=-=-=-=-=-=- _h1 
  ^h1 DESCRIPTION DU DOSSIER _h1 
  ^-  =-=-=-=-=-=-=-=-=-=-=- _h1 

  Le dossier contient 19 fichiers numérotés de 00 à 18 et listés ci-dessous :

   ^= 00_ReadMe_beans_EN.txt        _= 
   ^= 01_ReadMe_beans_FR.txt        _= 
   ^= 02_WRIML_documentation.md     _= 
                                  
   ^= 03_beans_pictures.svg         _=   
   ^= 04_all_in_one.png             _= 
   ^= 05_all_in_only_one.png        _=  
   ^= 06_each_in_one.png            _= 
   ^= 07_not_all_in_one_1.png       _= 
   ^= 08_not_all_in_one_2.png       _= 
   ^= 09_not_all_in_one_3.png       _= 
   ^= 10_not_all_in_one_4.png       _= 
   ^= 11_not_all_in_one_5.png       _=   
   ^= 12_not_all_in_one_6.png       _=   
   ^= 13_not_all_in_one_7.png       _= 
   ^= 14_not_all_in_only_one_1.png  _= 
   ^= 15_not_all_in_only_one_2.png  _= 
   ^= 16_not_all_in_only_one_3.png  _= 
   ^= 17_not_all_in_only_one_4.png  _= 
   ^= 18_not_all_in_only_one_5.png  _= 
   ^= 19_not_all_in_only_one_6.png  _=   
   ^= 20_not_all_in_only_one_7.png  _=   
   ^= 21_not_each_in_one_1.png      _= 
   ^= 22_not_each_in_one_2.png      _=   
   ^= 23_not_each_in_one_3.png      _=   
   ^= 24_not_each_in_one_4.png      _=   
   ^= 25_not_each_in_one_5.png      _= 
   ^= 26_not_each_in_one_6.png      _=  
   ^= 27_not_each_in_one_7.png      _= 

Le fichier "02_WRIML_documentation.md" est une présentation détaillée de WRIML, téléchargeable également depuis github.com/dbjoshua/WRIML-presentation avec d’autres documents d’introduction.

Le fichier "03_grains_images.svg" est le fichier source créé avec Inkscape tandis que les fichiers 03-* à 27-* sont les images exportées.


  ^-  =-=-=-=-=-=-=-=-=-=-=-=- _h1 
  ^h1 APERÇU DES IMAGES _h1 
  ^-  =-=-=-=-=-=-=-=-=-=-=-=- _h1 

Le matériel contient 8 images où l’on voit des grains dans des pots.

Les images "all_in_one" testent la portée large du quantificateur universel sur le quantificateur existentiel : Pour chaque grain, il existe au moins un pot dans lequel ce grain est.

Les images "each_in_one" testent la distributivité : Chaque grain est dans son propre pot.

Les images "all_in_only_one" testent la portée large du quantificateur existentiel par rapport au quantificateur universel : Il existe un pot qui contient tous les grains.

Les images avec le préfixe "not_*" testent les cas où les scénarios précédents sont "faux".  
Les suffixes "*_1" à "*_7" indiquent le nombre de grains en dehors des pots (respectivement 1 à 7 grains).  

Par conséquent, les images avec le suffixe "*_7" servent à tester la négation du quantificateur existentiel ou la portée large du quantificateur universel sur la négation.


  ^-  -=-=-=-=-=-=-=-=-=-=-=-= _-
  ^h1 GUIDE D’UTILISATION (MÉTHODOLOGIE) _h1 
  ^-  -=-=-=-=-=-=-=-=-=-=-=-= _-

Les matériaux ont été conçus comme contextes pour des phrases à traduire.
Les principales tâches soumises aux consultants sont une tâche de traduction suivie d’une tâche de jugement de valeur de vérité   ^cité Tonhauser & Mathewson 2015 _cité (   ^_bibref_doc-auteur="Tonhauser, Judith and Mathewson, Lisa"_doc-titre="Empirical evidence in research on meaning"_doc-type="ms"_lieu_pub="en ligne"_doc-éditeur="The Ohio State University, University of British Columbia" ).

Merci de suivre les étapes suivantes :

  ^procédure

   ^étape_ID="1" Demander au consultant de traduire les 12 phrases stimuli (voir ci-dessous) _étape  

   ^rem S’il existe plusieurs traductions possibles, les différencier avec des lettres suffixées au numéro correspondant à la phrase témoin. _rem 
   
    ^étape_ID="2" Pour chaque phrase obtenue, présenter successivement les 23 images de cette série et demander au locuteur si cette phrase est vraie dans le contexte représenté par l’image. _étape 

  _procédure 

  ^phrases_stimuli 
   ^= 01. Tous les grains sont dans une assiette.               _= 
   ^= 02. Tous les grains ne sont pas dans une assiette.        _= 
   ^= 03. Quelques grains sont dans une assiette.               _= 
   ^= 04. Quelques grains ne sont pas dans une assiette.        _= 
   ^= 05. Aucun grain n’est dans une assiette.                  _= 
   ^= 06. Chaque grain est dans une assiette.                   _= 
   ^= 07. Plusieurs grains sont dans une assiette.              _= 
   ^= 08. Plusieurs grains ne sont pas dans une assiette.       _= 
   ^= 09. Beaucoup de grains sont dans une assiette.            _= 
   ^= 10. Beaucoup de grains ne sont pas dans une assiette.     _= 
   ^= 11. La plupart des grains sont dans une assiette.         _= 
   ^= 12. La plupart des grains ne sont pas dans une assiette.  _= 
  _phrases_stimuli 

  ^-  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= _- 
  ^h1 INFORMATIONS RELATIVES A L'UTILISATION DE CE MATERIEL _h1
  ^-  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= _- 

  ^licence Les présents matériaux sont distribués sous licence Creative Commons CC-BY-NC-SA 4.0 _licence
  ^url Ils sont disponibles sur github.com/dbjoshua/visualmaterials _url

  ^_*

 _readme
