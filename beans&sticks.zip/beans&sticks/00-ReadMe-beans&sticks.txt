 ^ReadMe

 ^- File generated on: 2024/05/31 _-
 ^- Last update: 2024/05/31 _-

   ^- -------- _-
   ^/ METADATA _/
   ^- -------- _-

    ^title Seeds pictures for quantification _title
    ^version 1.0.0 _version

    ^time-needed 1 hour (estimated) _time-needed

    ^topic  Semantics of modified numerals  _topic

    ^background
      These material is inspired and primarily intended to help Language Experts in the project "The typology of cumulativity" (url) in collecting data to answer the questionnaire on modified numerals.
    _background

    ^target
      ^*  Testing the availability of distributive reading with modified numerals _*
      ^*  Testing the availability of cumulative reading with modified numerals _*
      ^*  Testing the possibility to force distributive reading of modified numerals via a special strategy _*
    _target

    ^creator
      ^name_family  Akpoué          _name
      ^name_given   Kouamé Josué    _name
      ^email        josueakpoue@gmail.com   _email
      ^orcid        0000-0002-8384-6516     _orcid
    _creator

   ^- ---------------------- _-
   ^/ TECHNICAL INFORMATIONS _/
   ^- ---------------------- _-

   ^// Language used in this file _//

   This file is written using the WRIML language which is a new markup language (see 01-WRIML-documentation-EN.md (downloaded from github.com/dbjoshua/WRIML-presentation) for a detailed description of the language).
   Hopefully, the document should be readable as is. But you may find useful to read the documentation for a better understanding so that you may also use it
   for your own documents in the future.
   The number of slash "/" indicates the level of the heading. * indicates an item. The empty tag ^tag_code="^_*" * _tag  at the end is just a funny emoji
   saying "Thank you for reading!".

   ^// Source files and images _//

   ^software
     ^name      LibreOffice Draw _name
     ^function  Create the source files (.odg) and export to PNG _function
   _software


   ^// Credits _//

   These materials use pictures downloaded from Pixabay (https://pixabay.com)


   ^- ------------------------- _-
   ^/ DESCRIPTION OF THE FOLDER _/
   ^- ------------------------- _-

   The folder contains 19 files numbered from 00 to 18 and listed bellow:

   ^* 00-ReadMe-beans&sticks.txt _*
   ^* 01-WML-documentation-EN.md _*

   ^* 02-odg-01-individual-cumulative-scenario.odg _*
   ^* 03-odg-02-individual-distributive-scenario.odg _*
   ^* 04-odg-03-event-cumulative-scenario-1.odg _*
   ^* 05-odg-04-event-cumulative-scenario-2.odg _*
   ^* 06-odg-05-event-cumulative-scenario-3.odg _*
   ^* 07-odg-06-event-cumulative-scenario-4.odg _*
   ^* 08-odg-07-event-distributive-scenario-1.odg _*
   ^* 09-odg-08-event-distributive-scenario-2.odg _*
   ^* 10-odg-09-event-scenarios-source.odg _*

   ^* 11-png-01-individual-cumulative-scenario.png _*
   ^* 12-png-02-individual-distributive-scenario.png _*
   ^* 13-png-03-event-cumulative-scenario-1.png _*
   ^* 14-png-04-event-cumulative-scenario-2.png _*
   ^* 15-png-05-event-cumulative-scenario-3.png _*
   ^* 16-png-06-event-cumulative-scenario-4.png _*
   ^* 17-png-07-event-distributive-scenario-1.png _*
   ^* 18-png-08-event-distributive-scenario-2.png _*

   The file 01-WRIML-documentation-EN.md is a detailed presentation of WRIML which can also be downloaded
   from github.com/dbjoshua/WRIML-presentation alongside with other documentation and introduction files which are roughly
   the same as this file but in different formats and/or language.

   The files 02-* to 10-* are the source files created using LibreOffice Draw while the files 11-* to 18-* are the output pictures.


   ^- ------------------------ _-
   ^/ OVERVIEW OF THE PICTURES _/
   ^- ------------------------ _-

   The materials contain 08 pictures in which one can see sticks in contact with coffee beans.
   Each picture name has 4 parts separated by "-":

   ^* The order number in the folder: used as file identifier _*
   ^* The prefix indicating the format of the file: png. _*
   ^* The ID number of the picture: used to identify the picture is the set. It is the one that will be used henceforth to refer to the picture. _*
   ^* The scenario description: indicates the type of scenario depicted in the picture. _*

   The pictures 03 to 08 depict two scenes occurring at different times (as the time in the clocks suggest).


   ^- ------------------------ _-
   ^/ USER GUIDE (METHODOLOGY) _/
   ^- ------------------------ _-

   The materials were designed to serve as contexts for translated sentences. They were originally designed to help Language Experts in the project ^link_url="https://sites.google.com/view/the-typology-of-cumulativity/home" The typology of cumulativity _link  provide supporting data for the answers to the questions ([Q1] to [Q3]) in the ^link_url="https://sites.google.com/view/the-typology-of-cumulativity/questionnaires?authuser=0" questionnaire on distributive universals _link .
   The main tasks the consultants are to be submitted to are a translation task followed by a truth value judgement task ^cited Tonhauser & Mathewson 2015 _cited ( ^_bibref_doc-author="Tonhauser, Judith and Mathewson, Lisa"_doc-title="Empirical evidence in research on meaning"_doc-type="ms"_pub-place="online"_doc-publisher="The Ohio State University, University of British Columbia" ).

   Please follow the following steps:

   ^steps_case="For answer to [Q1] Do simple sentences containing numerals (in object position) in your language allow for both a cumulative and a distributive reading?"
     ^step_ID="1"   Ask the consultant to translate the sentence (P1) "The two sticks touch three beans." (or in French "Les deux brindilles/bâtons
                    touchent trois graines.") in his/her language. _step

     ^step_ID="2"   Present the picture 01 to the consultant and ask him/her if the translation of (P1) previously provided is TRUE in this scenario. _step

     ^step_ID="3"   Repeat Step 2 using picture 02. _step
   _steps

   ^answer The answer to [Q1] will be YES if you got "yes" as answer in both Step 2 and Step 3. _answer

   ^note For a detailed description of the notion of modification of the numeral in object position and constituency, please do refer to the original
         questionnaire available on ^link_url="https://sites.google.com/view/the-typology-of-cumulativity/questionnaires?authuser=0" this page _link

   ^steps_case="For answer to [Q2] Regarding the sentences you provide in Q1: Is there a strategy of modifying the numeral noun in object so that a distributive reading is forced and distribution over individuals is possible?"
     ^step_ID="1"   Ask the consultant whether there exist a way of modifying the expression meaning "three beans" (in French "trois graines")
                    - e.g. by adding another word or something like this to it - so that the resulting sentence is only true in the context
                    of image 02 _step
   _steps

   ^answer The answer to [Q2] is "yes" if the consultant can provide such a sentence. _answer

   ^note If the consultant is not able to provide such a sentence. Perhaps you should consider explaining what you want a bit more and ask for other
         sentences independent from the one suggested here. _note

   ^steps_case="For answer to [Q3] Regarding the sentences you provide in Q1: Is there a strategy of modifying the numeral noun in object so that a distributive reading is forced and distribution over events is possible?"
     ^step_ID="1"   Present the pictures 03 to 08 to the consultant and ask him whether the translation of the sentence (P1)
                    is true is these contexts. _step

     ^step_ID="2"   Present the pictures 03 to 08 to the consultant and ask him whether the modified version of the translation of the sentence (P1)
                    is true is these contexts. If the sentence is only true in the context of images 07 and 08. You may stop here. The answer
                    for [Q3] in this language being "yes". If not, go to Step 3 _step

     ^step_ID="3"   Ask the consultant whether there exist a way of modifying the expression meaning "three beans" (in French "trois graines")
                    - e.g. by adding another word or something like this to it - so that the resulting sentence is only true in the context
                    of image 07 to 08 (not in the context of images 03 to 06). The answer to [Q3] in this language will be true if the consultant
                    is able to provide such an expression. _step
   _steps

   ^note You may also go to step 3 if you want to know if there exists an other way to modify the numeral in object position so as to force distribution
         over events _note

   ^- -------------------- _-
   ^/ SHARING INFORMATIONS _/
   ^- -------------------- _-

   The present materials are distributed under the license of the terms of license Creative Commons CC-BY-NC-SA 4.0
   They are available at github.com/dbjoshua/visualmaterials


 ^_*

 _ReadMe
